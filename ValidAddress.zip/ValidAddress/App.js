// In App.js in a new project

import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './js/Login'
import MapScreen from './js/Map'

const Stack = createStackNavigator();

function App() {
  console.disableYellowBox = true;
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="Login" component={Login} 
        options={{
          headerShown: false,
        }}/>
        <Stack.Screen name="Home" component={MapScreen} 
        options={{ 
          title: 'Address',
          headerStyle: {
            backgroundColor: '#023e3f',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
              fontWeight: 'medium',
          },
          headerLeft: () => (
            <Button
              title=""
              backgroundColor="#023e3f"
              color="#023e3f"
            />
          ),
        }}
      />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;