
// function fetchCities() {
//     return dispatch => {
//         //dispatch(fetchUserPending());
//         fetch('https://uniquecityvalidator.azurewebsites.net/api/getValidAddresses', {
//             method: 'POST',
//             headers: {
//                 Accept: 'application/json',
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({
//                 name: 'anildeshmukh@outlook.com',
//             })
//         })
//         .then(res => res.json())
//         .then(res => {
//             if(res.error) {
//                 throw(res.error);
//             }
//             //dispatch(fetchUserSuccess(res.results[0].user));
//             console.log('value ', res.results[0].user);
//         })
//         .catch(error => {
//             //dispatch(fetchUserError(error));
//             console.log('value ', error);
//         })
//     }
// }

// function fetchCities() {
//     return dispatch => {
//         //dispatch(fetchUserPending());
//         fetch('https://randomuser.me/api/0.4/?randomapi')
//         .then(res => res.json())
//         .then(res => {
//             if(res.error) {
//                 throw(res.error);
//             }
//             //dispatch(fetchUserSuccess(res.results[0].user));
//             console.log('value ', res.results[0].user);
            
//             //return res.results[0].user;
//         })
//         .catch(error => {
//             console.log('value ', error);
//             //dispatch(fetchUserError(error));
//         })
//     }
// }

async function fetchCities() {
    try {
      let response = await fetch('https://uniquecityvalidator.azurewebsites.net/api/getValidAddresses', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: 'anil',
            })
        });
      let result = await response.json();
      //console.log('result', result.results[0].user);
      
      this.setState({
        city: result,
        isLoaded: true,
      }, ()=> {
        console.log('city 1', this.state.city);
      });
    } catch (err) {
      alert('error ', JSON.stringify(err));
    }
  };

export default fetchCities;