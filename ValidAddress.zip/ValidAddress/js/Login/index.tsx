import React from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';
import fetchCities from '../api/AddressApi';

export default class App extends React.Component {
  async _onPressLogin() {
   await fetchCities();

    this.props.navigation.navigate('Home', {
      deeplinkRouteName: 'Home',
    });
  }

  render(){
    return (
      <View style={styles.container}>
        <Text style={styles.logo}>Validate City</Text>
      
        <TouchableOpacity style={styles.loginBtn} onPress={this._onPressLogin.bind(this)}>
          <Text style={styles.loginText}>Press Me</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#59b2ab',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo:{
    fontWeight:"bold",
    fontSize:30,
    color:"white",
    marginBottom:40
  },
  loginBtn:{
    width:"80%",
    backgroundColor:"#febe29",
    borderRadius:25,
    height:50,
    alignItems:"center",
    justifyContent:"center",
    marginTop:40,
    marginBottom:10
  },
  loginText:{
    color:"white"
  }
});